const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: 'kaua0910', // Altere para a sua senha do MySQL, se houver
    database: 'funcionarios'
};

const db = mysql.createPool(dbConfig);

// GET /api/funcionarios
app.get('/api/funcionarios', async (req, res) => {
    try {
        const [rows] = await db.execute('SELECT id, nome, funcao, salario FROM funcionarios ORDER BY id DESC');
        res.json(rows);
    } catch (error) {
        console.error('Erro no GET:', error.message);
        res.status(500).json({ error: error.message });
    }
});

// POST /api/funcionarios
app.post('/api/funcionarios', async (req, res) => {
    try {
        const { nome, funcao, salario } = req.body;
        if (!nome || !funcao || !salario) {
            return res.status(400).json({ error: 'Campos obrigatórios faltando' });
        }
        const [result] = await db.execute(
            'INSERT INTO funcionarios (nome, funcao, salario, status) VALUES (?, ?, ?, "ativo")',
            [nome, funcao, parseFloat(salario)]
        );
        res.json({ success: true, id: result.insertId, nome, funcao, salario });
    } catch (error) {
        console.error('Erro no POST:', error.message);
        res.status(500).json({ error: error.message });
    }
});

// PUT /api/funcionarios/:id
app.put('/api/funcionarios/:id', async (req, res) => {
    try {
        const { nome, funcao, salario } = req.body;
        const id = req.params.id;
        await db.execute(
            'UPDATE funcionarios SET nome = ?, funcao = ?, salario = ? WHERE id = ?',
            [nome, funcao, parseFloat(salario), id]
        );
        res.json({ success: true });
    } catch (error) {
        console.error('Erro no PUT:', error.message);
        res.status(500).json({ error: error.message });
    }
});

// DELETE /api/funcionarios/:id
app.delete('/api/funcionarios/:id', async (req, res) => {
    try {
        const id = req.params.id;
        await db.execute('DELETE FROM funcionarios WHERE id = ?', [id]);
        res.json({ success: true });
    } catch (error) {
        console.error('Erro no DELETE:', error.message);
        res.status(500).json({ error: error.message });
    }
});

const PORT = 3001;
app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
});